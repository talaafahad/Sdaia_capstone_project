import { useState } from 'react'
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import HeroSection from './components/HeroSection'
import HowItWorks from './components/HowItWorks'
import IntakeForm from './components/IntakeForm'
import AgentRoster from './components/AgentRoster'
import ApprovalModal from './components/ApprovalModal'
import ConflictModal from './components/ConflictModal'
import type { FormValues, AgentCard, ConflictData } from './types/bosalah'

// ─── Demo state ───────────────────────────────────────────────────────────────

const EMPTY_FORM: FormValues = {
  businessGoal: '',
  businessCategory: '',
  city: '',
  district: '',
  applicantStatus: '',
  areaSqm: '',
  annualRevenueSAR: '',
  budgetSAR: '',
  numberOfEmployees: '',
  targetOpeningDate: '',
  applicantAge: '',
}

const DEMO_AGENTS: AgentCard[] = [
  {
    name: 'Intake & Planner',
    description: 'Parses your goal, extracts structured requirements, and drafts the execution plan.',
    badge: 'LLM',
    status: 'completed',
  },
  {
    name: 'Regulation & Service Router',
    description: 'Identifies applicable regulations, licences, and government portals.',
    badge: 'LLM',
    status: 'working',
  },
  {
    name: 'Municipal & Location',
    description: 'Verifies zoning, municipal permits, and nearby competitor density.',
    badge: 'A2A',
    status: 'waiting',
  },
  {
    name: 'Tax / Financial',
    description: 'Calculates VAT registration thresholds, fee estimates, and GOSI obligations.',
    badge: 'DETERMINISTIC',
    status: 'waiting',
  },
  {
    name: 'Verifier',
    description: 'Cross-checks every claim against cited sources. Flags hallucinations.',
    badge: 'LLM',
    status: 'waiting',
  },
  {
    name: 'Documentation',
    description: 'Assembles the final checklist, cover letter, and ready-to-submit packet.',
    badge: 'LLM',
    status: 'waiting',
  },
]

const DEMO_CONFLICT: ConflictData = {
  label: 'Premises area discrepancy',
  valueA: '120 sqm',
  sourceA: 'Intake form — applicant stated value',
  valueB: '118 sqm',
  sourceB: 'Lease agreement (extracted from uploaded PDF, clause 3.1)',
}

// ─── App ──────────────────────────────────────────────────────────────────────

export default function App() {
  const [formValues, setFormValues] = useState<FormValues>(EMPTY_FORM)
  const [showApproval, setShowApproval] = useState(false)
  const [showConflict, setShowConflict] = useState(false)
  const [uploadedFileName, setUploadedFileName] = useState<string | null>(null)

  function handleFormChange(field: keyof FormValues, value: string) {
    setFormValues(prev => ({ ...prev, [field]: value }))
  }

  function handleFormSubmit(values: FormValues) {
    console.log('Form submitted:', values)
    setShowApproval(true)
  }

  function handleFileChange(file: File | null) {
    if (!file) return
    setUploadedFileName(file.name)
    const DOCUMENT_AREA = 118
    const formArea = parseFloat(formValues.areaSqm)
    if (!isNaN(formArea) && formArea !== DOCUMENT_AREA) {
      setShowConflict(true)
    } else if (formValues.areaSqm === '') {
      setShowConflict(true)
    }
  }

  function handleSuggestedCase(text: string) {
    setFormValues(prev => ({ ...prev, businessGoal: text }))
    document.getElementById('intake')?.scrollIntoView({ behavior: 'smooth' })
  }

  function handleStartClick() {
    document.getElementById('intake')?.scrollIntoView({ behavior: 'smooth' })
  }

  const completedCount = DEMO_AGENTS.filter(a => a.status === 'completed').length
  const overallProgress = Math.round((completedCount / DEMO_AGENTS.length) * 100)

  return (
    <div className="min-h-screen text-text-primary" style={{ background: '#10122B' }}>
      <Navbar />

      <div className="pt-14">
        <HeroSection
          tagline="Your compass through Saudi government procedures."
          onSuggestedCaseClick={handleSuggestedCase}
          onStartClick={handleStartClick}
        />
      </div>

      <HowItWorks />

      <div className="max-w-7xl mx-auto px-6">
        <div className="saudi-bar rounded-full" style={{ height: 1, opacity: 0.25 }} />
      </div>

      <section className="py-8 px-6">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-10 items-start">
          <div className="lg:col-span-2">
            <IntakeForm
              values={formValues}
              onChange={handleFormChange}
              onSubmit={handleFormSubmit}
              onFileChange={handleFileChange}
            />
            {uploadedFileName && (
              <p className="mt-3 text-xs" style={{ color: '#5BCD84' }}>
                ✓ Document uploaded: {uploadedFileName} — conflict detection ran automatically.
              </p>
            )}
          </div>

          <div className="lg:sticky lg:top-20">
            <AgentRoster agents={DEMO_AGENTS} overallProgress={overallProgress} />
          </div>
        </div>
      </section>

      <Footer />

      <ApprovalModal
        isOpen={showApproval}
        caseSummary={{
          businessGoal:     formValues.businessGoal || 'Open a specialty coffee shop in Al-Olaya, Riyadh.',
          category:         formValues.businessCategory || 'Food & Beverage',
          city:             formValues.city || 'Riyadh',
          district:         formValues.district || 'Al-Olaya',
          applicantStatus:  formValues.applicantStatus || 'saudi',
          areaSqm:          formValues.areaSqm || '118 (resolved)',
          annualRevenueSAR: formValues.annualRevenueSAR || '500,000',
          requiredLicences: ['Commercial Registration', 'Municipality Licence', 'Food Safety Certificate'],
          estimatedFees:    'SAR 4,200 – 6,800',
          readinessScore:   '87%',
        }}
        onApprove={() => setShowApproval(false)}
        onDisapprove={reason => { console.log('Sent back:', reason); setShowApproval(false) }}
      />

      <ConflictModal
        isOpen={showConflict}
        conflict={DEMO_CONFLICT}
        onResolveConflict={val => {
          if (typeof val === 'string') {
            const num = val.replace(/[^0-9.]/g, '')
            if (num) setFormValues(prev => ({ ...prev, areaSqm: num }))
          }
          setShowConflict(false)
        }}
        onClose={() => setShowConflict(false)}
      />
    </div>
  )
}
