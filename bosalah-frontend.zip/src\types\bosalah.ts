// ─── Agent types ──────────────────────────────────────────────────────────────

export type AgentStatus = 'waiting' | 'working' | 'completed' | 'error'

export type AgentBadge = 'LLM' | 'A2A' | 'DETERMINISTIC'

export interface AgentCard {
  name: string
  description: string
  badge: AgentBadge
  status: AgentStatus
}

// ─── Intake form types ────────────────────────────────────────────────────────

export type ApplicantStatus = '' | 'saudi' | 'gcc' | 'non_gcc'

export interface FormValues {
  // Required fields
  businessGoal: string
  businessCategory: string
  city: string
  district: string
  /** Use ApplicantStatus values; typed as string so generic onChange(field, string) works */
  applicantStatus: string
  areaSqm: string
  annualRevenueSAR: string

  // Optional fields
  budgetSAR: string
  numberOfEmployees: string
  targetOpeningDate: string
  applicantAge: string
}

// ─── Modal types ──────────────────────────────────────────────────────────────

export type CaseSummary = string | Record<string, unknown>

export interface ConflictData {
  label: string
  valueA: string | number
  sourceA: string
  valueB: string | number
  sourceB: string
}


